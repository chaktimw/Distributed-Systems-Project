import pymongo
from database import database_tools

publisher_name = "cheap_shark"

    # for game in data:
    #     line = "<b>Title:</b> " + game['title'] + \
    #            " <b>Normal Price:</b> " + game['normalPrice'] + \
    #            " <b>Sale Price:</b> " + game['salePrice']
    #     html_view += line + "<br>"
    # return render_template('subscriber.html', Comments=html_view)


def publish(data):
    counter = data['counter']
    raw_data = data['raw_data']
    game = raw_data[counter]
    price = game['salePrice']

    database_tools.add_event(game)

    filters = database_tools.get_publisher_topics(publisher_name)
    result = []
    for x in filters:
        filter_price = int(x)
        if int(float(price)) <= filter_price:
            database_tools.update_filter(x, game)
            result.append(filter_price)
    return (game, result)


def get_advertised():
    return database_tools.get_publisher_topics(publisher_name)


def advertise(value):
    current_topics = database_tools.get_publisher_topics(publisher_name)

    if value not in current_topics:
        database_tools.add_filter(value)
        result = database_tools.update_publisher(publisher_name, [value])
        return result
    else:
        return -1


def deadvertise(value):
    current_topics = database_tools.get_publisher_topics(publisher_name)
    if value in current_topics:
        database_tools.remove_filter(value)
        result = database_tools.update_publisher_remove(publisher_name, value)
        return result
    else:
        return current_topics
